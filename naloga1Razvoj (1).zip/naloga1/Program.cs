﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace naloga1
{
    class Program
    {
        static string imeDatoteke = "artikli.txt";
        static string imeFiltriraneDatoteke = "filtrirani_artikli.txt";
        static string imeAkcijskeDatoteke = "akcija_artikli.txt";

        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            bool konec = false;

            while (!konec)
            {
                PrikaziMeni();
                string izbira = Console.ReadLine();

                switch (izbira)
                {
                    case "1":
                        ShraniArtikel();
                        break;
                    case "2":
                        BeriVseArtikle();
                        break;
                    case "3":
                        IsciPoDobaviiteljuInZalogah();
                        break;
                    case "4":
                        ZnizajCene();
                        break;
                    case "5":
                        konec = true;
                        Console.WriteLine("\n Konec");
                        break;
                    default:
                        Console.WriteLine("\nPoskusite ponovno.");
                        break;
                }
                if (!konec)
                {
                    Console.WriteLine("\nPritisnite tipko");
                    Console.ReadKey();
                    Console.Clear();
                }
            }
        }

        static void PrikaziMeni(){
            Console.WriteLine("1. Shrani nov artikel");
            Console.WriteLine("2. Prikazi vse artikle");
            Console.WriteLine("3. Isci po dobavitelju in zalogah");
            Console.WriteLine("4. popust");
            Console.WriteLine("5. Izhod");
            Console.WriteLine("");
            Console.Write("Izbira: ");
        }

        static void ShraniArtikel()
        {
            Console.WriteLine("\n dodaj nov artikel");

            Console.Write("ime izdelka: ");
            string ime = Console.ReadLine();

            Console.Write("cena izdelka: ");
            decimal cena;
            while (!decimal.TryParse(Console.ReadLine(), NumberStyles.Any, CultureInfo.InvariantCulture, out cena) || cena < 0)
            {
                Console.Write("Napaka, vnesite veljavno ceno: ");
            }

            Console.Write("Zaloge (kolicina) : ");
            int zaloge;
            while (!int.TryParse(Console.ReadLine(), out zaloge) || zaloge < 0)
            {
                Console.Write("napaka , vnesite stevilo zaloge ");
            }

            Console.Write("Dobavitelj:");
            string dobavitelj = Console.ReadLine();

            Artikel artikel = new Artikel(ime, cena, zaloge, dobavitelj);

            try
            {
                using (StreamWriter writer = new StreamWriter(imeDatoteke, true))
                {
                    writer.WriteLine(artikel.VNiz());
                }
                Console.WriteLine($"\nArtikel '{ime}' uspesno shranjen!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\n napaka {ex.Message}");} }

        static void BeriVseArtikle()
        {
            Console.WriteLine("\n vsi izdelki: ");

            if (!File.Exists(imeDatoteke))
            {
                Console.WriteLine("Datoteka se ne obstaja, dodajte artikle.");
                return;
            }

            try
            {
                using (StreamReader reader = new StreamReader(imeDatoteke))
                {
                    string vrstica;
                    int stevilka = 1;
                    bool najden = false;

                    while ((vrstica = reader.ReadLine()) != null)
                    {
                        najden = true;
                        Artikel artikel = PreberiArtikelIzVrstice(vrstica);
                        if (artikel != null)
                        {
                            Console.WriteLine($"\n{stevilka}. Artikel:");
                            Console.WriteLine($"Ime: {artikel.Ime}");
                            Console.WriteLine($"Cena: {artikel.Cena:F2} €");
                            Console.WriteLine($"Zaloge: {artikel.Zaloge} kos");
                            Console.WriteLine($"Dobavitelj: {artikel.Dobavitelj}");
                            stevilka++;
                        }
                    }

                    if (!najden)
                    {
                        Console.WriteLine("ni shranjenih artiklov");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Napaka pri branju {ex.Message}");
            }
        }

        static void IsciPoDobaviiteljuInZalogah()
        {
            Console.WriteLine("\n iskanje izdelkov");

            if (!File.Exists(imeDatoteke))
            {
                Console.WriteLine("Datoteka se ne obstaja. Najprej dodajte artikle.");
                return;
            }

            Console.Write("Vnesite ime dobavitelja: ");
            string iskanDobavitelj = Console.ReadLine().ToLower();

            Console.Write("Vnesite maksimalno število zaloge: ");
            int maxZaloge;
            while (!int.TryParse(Console.ReadLine(), out maxZaloge) || maxZaloge < 0)
            {
                Console.Write("Napaka! Vnesite veljavno število: ");
            }

            List<Artikel> najdeniArtikli = new List<Artikel>();

            try
            {
                using (StreamReader reader = new StreamReader(imeDatoteke))
                {
                    string vrstica;
                    while ((vrstica = reader.ReadLine()) != null)
                    {
                        Artikel artikel = PreberiArtikelIzVrstice(vrstica);
                        if (artikel != null &&
                            artikel.Dobavitelj.ToLower().Contains(iskanDobavitelj) &&
                            artikel.Zaloge < maxZaloge)
                        {
                            najdeniArtikli.Add(artikel);
                        }
                    }
                }

                if (najdeniArtikli.Count > 0) {
                    Console.WriteLine($"\n✓ Najdenih {najdeniArtikli.Count} artiklov:");

                    int stevilka = 1;
                    foreach (var artikel in najdeniArtikli)
                    {
                        Console.WriteLine($"\n{stevilka}. {artikel.Ime}");
                        Console.WriteLine($"   Cena: {artikel.Cena:F2} €");
                        Console.WriteLine($"   Zaloge: {artikel.Zaloge} kos");
                        Console.WriteLine($"   Dobavitelj: {artikel.Dobavitelj}");
                        stevilka++;}
                    using (StreamWriter writer = new StreamWriter(imeFiltriraneDatoteke, false))
                    {
                        writer.WriteLine($"Filtrirani artikli - Dobavitelj: {iskanDobavitelj}, Zaloge < {maxZaloge}");
                        writer.WriteLine("=".PadRight(60, '='));
                        foreach (var artikel in najdeniArtikli)
                        {
                            writer.WriteLine(artikel.VNiz());
                        }
                    }

                    Console.WriteLine($"\nRezultati shranjeni v '{imeFiltriraneDatoteke}'"); }
                else
                {
                    Console.WriteLine("\nNi najdenih artiklov s tem kriterijem.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"✗ Napaka: {ex.Message}");
            }
        }
        static void ZnizajCene()
        {
            Console.WriteLine("\n popusti");

            if (!File.Exists(imeDatoteke))
            {
                Console.WriteLine("Datoteka še ne obstaja. Najprej dodajte artikle.");
                return;}
            List<Artikel> vsiArtikli = new List<Artikel>();

            try{
                using (StreamReader reader = new StreamReader(imeDatoteke))
                {
                    string vrstica;
                    while ((vrstica = reader.ReadLine()) != null)
                    {
                        Artikel artikel = PreberiArtikelIzVrstice(vrstica);
                        if (artikel != null)
                        {
                            vsiArtikli.Add(artikel); } }}

                if (vsiArtikli.Count == 0){
                    Console.WriteLine("ni shranjenih izdelkov.");
                    return; }

                List<Artikel> akcijskiArtikli = new List<Artikel>();
                bool nadaljuj = true;

                while (nadaljuj)
                {
                    Console.WriteLine("\n izdelki na zalogi");
                    for (int i = 0; i < vsiArtikli.Count; i++)
                    {
                        Console.WriteLine($"{i + 1}. {vsiArtikli[i].Ime} - {vsiArtikli[i].Cena:F2} €");
                    }

                    Console.Write("\nIzberi stevilko izdelka: ");
                    int izbira;
                    while (!int.TryParse(Console.ReadLine(), out izbira) || izbira < 1 || izbira > vsiArtikli.Count)
                    {
                        Console.Write("Napaka! Vnesite številko od 1 do " + vsiArtikli.Count + ": ");
                    }

                    Artikel izbranArtikel = vsiArtikli[izbira - 1];

                    Console.Write($"Popust za '{izbranArtikel.Ime}' (v %): ");
                    decimal odstotek;
                    while (!decimal.TryParse(Console.ReadLine(), NumberStyles.Any, CultureInfo.InvariantCulture, out odstotek) || odstotek < 0 || odstotek > 100)
                    {
                        Console.Write("Napaka! Vnesite odstotek med 0 in 100: ");
                    }
                    decimal novaCena = izbranArtikel.Cena * (1 - odstotek / 100);
                    Artikel akcijskiArtikel = new Artikel(izbranArtikel.Ime, novaCena, izbranArtikel.Zaloge, izbranArtikel.Dobavitelj);
                    akcijskiArtikli.Add(akcijskiArtikel);

                    Console.WriteLine($"'{izbranArtikel.Ime}' dodan v akcijo!");
                    Console.Write("\nŽeliš dodati še en artikel v akcijo? (da/ne): ");
                    string odgovor = Console.ReadLine().ToLower();
                    nadaljuj = (odgovor == "da" || odgovor == "d");
                }
                if (akcijskiArtikli.Count > 0)
                {
                    Console.WriteLine(" izdelki z popustom");
                    using (StreamWriter writer = new StreamWriter(imeAkcijskeDatoteke, false)){
                        for (int i = 0; i < akcijskiArtikli.Count; i++)
                        {
                            Console.WriteLine($"\n{i + 1}. {akcijskiArtikli[i].Ime}");
                            Console.WriteLine($"Nova cena: {akcijskiArtikli[i].Cena:F2} €");
                            Console.WriteLine($"Zaloge: {akcijskiArtikli[i].Zaloge}");
                            Console.WriteLine($"Dobavitelj: {akcijskiArtikli[i].Dobavitelj}");

                            writer.WriteLine(akcijskiArtikli[i].VNiz());
                        }
                    }

                    Console.WriteLine($"\n {akcijskiArtikli.Count} artiklov shranjenih v '{imeAkcijskeDatoteke}'");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Napaka: {ex.Message}");
            }
        }
        static Artikel PreberiArtikelIzVrstice(string vrstica)
        {
            try
            {
                string[] deli = vrstica.Split(';');
                if (deli.Length >= 4)
                {
                    string ime = deli[0].Trim();
                    decimal cena = decimal.Parse(deli[1].Trim(), CultureInfo.InvariantCulture);
                    int zaloge = int.Parse(deli[2].Trim());
                    string dobavitelj = deli[3].Trim();

                    return new Artikel(ime, cena, zaloge, dobavitelj);
                }
            }
            catch
            {
            }
            return null;
        }
    }
}