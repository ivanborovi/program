﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace naloga1
{
    class Artikel
    {
        public string Ime { get; set; }
        public decimal Cena { get; set; }
        public int Zaloge { get; set; }
        public string Dobavitelj { get; set; }

        public Artikel(string ime, decimal cena, int zaloge, string dobavitelj)
        {
            Ime = ime;
            Cena = cena;
            Zaloge = zaloge;
            Dobavitelj = dobavitelj;
        }
        public string VNiz()
        {
            return $"{Ime};{Cena};{Zaloge};{Dobavitelj}";
        }
    }
}
