﻿namespace Preverjanje1a.src.Models
{
    internal class Student
    {
        public string Id { get; set; } = "";
        public string Ime { get; set; } = "";
        public string Priimek { get; set; } = "";
        public decimal Povprecje { get; set; }
        public int Letnik { get; set; } // 1-3
        public List<string> PredmetRefs { get; set; } = new();
        public override string ToString() => $"{Ime} {Priimek} | povp: {Povprecje} | letnik: {Letnik}";
    }
}
