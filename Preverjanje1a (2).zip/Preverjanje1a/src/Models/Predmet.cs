﻿namespace Preverjanje1a.src.Models
{
    internal class Predmet
    {
        public string Id { get; set; } = "";
        public string Naziv { get; set; } = "";
        public int ECTS { get; set; }
        public string Obvezen { get; set; } = "da"; // da|ne
        public string Predavatelj { get; set; } = "";

        public override string ToString() =>
            $"Ime: {Naziv} | ECTS: {ECTS} | Obvezen predmet: {Obvezen} | Predavatelj: {Predavatelj}";
    }
}