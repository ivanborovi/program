﻿using System.Xml;
using System.Xml.Schema;

namespace Preverjanje2b.src.Services;

public class ValidationService
{
    private bool _isValid = true;

    public bool Validate(string xmlPath, string xsdPath)
    {
        _isValid = true;

        try
        {
            XmlSchemaSet schemas = new XmlSchemaSet();
            schemas.Add("", xsdPath);

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.ValidationType = ValidationType.Schema;
            settings.Schemas = schemas;
            settings.ValidationEventHandler += ValidationEventHandler;

            using (XmlReader reader = XmlReader.Create(xmlPath, settings))
            {
                while (reader.Read()) { }
            }

            return _isValid;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Napaka pri validaciji: {ex.Message}");
            return false;
        }
    }

    private void ValidationEventHandler(object sender, ValidationEventArgs e)
    {
        if (e.Severity == XmlSeverityType.Error)
        {
            Console.WriteLine($"Napaka validacije: {e.Message}");
            _isValid = false;
        }
        else if (e.Severity == XmlSeverityType.Warning)
        {
            Console.WriteLine($"Opozorilo validacije: {e.Message}");
        }
    }
}