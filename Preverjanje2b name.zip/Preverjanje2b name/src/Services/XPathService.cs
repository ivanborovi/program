﻿using System.Xml;
using System.Xml.XPath;

namespace Preverjanje2b.src.Services;

public class XPathService
{
    private readonly XPathDocument _doc;
    private readonly XPathNavigator _nav;

    public XPathService(string xmlPath)
    {
        _doc = new XPathDocument(xmlPath);
        _nav = _doc.CreateNavigator();
    }

    public void IzpisiStOdlicnjakov()
    {
        string query = "//student/ime";
        Console.WriteLine("=== Vsa imena študentov ===");
        XPathNodeIterator iterator = _nav.Select(query);
        while (iterator.MoveNext())
        {
            Console.WriteLine(iterator.Current.Value);
        }
        Console.WriteLine();
    }

    public void IzpisiPredmeteZNadOceno(int minOcena)
    {
        string query = $"//predmet[ocena >= {minOcena}]/naziv";
        Console.WriteLine($"=== Predmeti z oceno >= {minOcena} ===");
        XPathNodeIterator iterator = _nav.Select(query);

        if (iterator.Count == 0)
        {
            Console.WriteLine("Ni predmetov z tako oceno.");
        }
        else
        {
            while (iterator.MoveNext())
            {
                Console.WriteLine(iterator.Current.Value);
            }
        }
        Console.WriteLine();
    }

    public void IzpisiStatistikoOcenLetnik(int letnik)
    {
        Console.WriteLine($"=== Statistika ocen za letnik {letnik} ===");

        string queryStudentov = $"count(//student[letnik={letnik}])";
        double stStudentov = (double)_nav.Evaluate(queryStudentov);
        Console.WriteLine($"Število študentov: {stStudentov}");

        string queryPovprecje = $"sum(//student[letnik={letnik}]/predmeti/predmet/ocena) div count(//student[letnik={letnik}]/predmeti/predmet/ocena)";
        double povprecje = (double)_nav.Evaluate(queryPovprecje);
        Console.WriteLine($"Povprečna ocena: {povprecje:F2}");

        string queryMax = $"//student[letnik={letnik}]/predmeti/predmet/ocena[not(. < ../../predmet/ocena)]";
        XPathNodeIterator maxIt = _nav.Select(queryMax);
        if (maxIt.MoveNext())
        {
            Console.WriteLine($"Najvišja ocena: {maxIt.Current.Value}");
        }

        string queryMin = $"//student[letnik={letnik}]/predmeti/predmet/ocena[not(. > ../../predmet/ocena)]";
        XPathNodeIterator minIt = _nav.Select(queryMin);
        if (minIt.MoveNext())
        {
            Console.WriteLine($"Najnižja ocena: {minIt.Current.Value}");
        }

        Console.WriteLine();
    }

    public void XpathNav(string query, XPathNavigator nav)
    {
        XPathNodeIterator it = nav.Select(query);
        Console.WriteLine("Results for query: " + query);
        while (it.MoveNext())
        {
            Console.WriteLine(it.Current.Value);
        }
        Console.WriteLine();
    }

    public void XpathEvaluate(string query, XPathNavigator nav)
    {
        string result = nav.Evaluate(query).ToString();
        Console.WriteLine("Results for query: " + query);
        Console.WriteLine(result);
    }
}