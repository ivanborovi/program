﻿using Preverjanje2b.src.Services;
using System.Globalization;

namespace Preverjanje2b.src;

class Program
{
    static void Main()
    {
        Console.WriteLine("Hello, World!");

        Console.OutputEncoding = System.Text.Encoding.UTF8;

        string baseDir = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, @"..\..\.."));
        string dataDir = Path.Combine(baseDir, "data");
        string outDir = Path.Combine(baseDir, "out");

        Directory.CreateDirectory(dataDir);
        Directory.CreateDirectory(outDir);

        // poti do datotek
        string xmlStudenti = Path.Combine(dataDir, "studenti.xml");
        string xsltHtml = Path.Combine(dataDir, "base.xsl");
        string xsltFo = Path.Combine(dataDir, "porociloPDF.xsl");
        string xsdUniversal = Path.Combine(dataDir, "UniversalSchema.xsd");

        // servisi
        var xmlQuery = new XPathService(xmlStudenti);
        var xslt = new XsltService();
        var pdf = new PdfService();
        var docx = new DocxService();
        var validator = new ValidationService();

        while (true)
        {
            Console.WriteLine("\n=== MENI (Preverjanje 2) ===");
            Console.WriteLine("1) XPath: izpiši vsa imena študentov");
            Console.WriteLine("2) XPath: izpiši predmete z oceno >= X");
            Console.WriteLine("3) XPath: statistika vseh ocen");
            Console.WriteLine("4) XSLT -> HTML: generiraj out/studenti.html");
            Console.WriteLine("5) XSLT -> PDF: generiraj out/porocilo.pdf");
            Console.WriteLine("6) DOCX: generiraj porocilo DOCX iz XML");
            Console.WriteLine("7) DOCX -> UniversalData.xml + validacija");
            Console.WriteLine("8) UniversalData.xml -> HTML + PDF");
            Console.WriteLine("0) Izhod");
            Console.Write("Izbira: ");
            var choice = Console.ReadLine();

            try
            {
                switch (choice)
                {
                    case "1":
                        xmlQuery.IzpisiStOdlicnjakov();
                        break;

                    case "2":
                        var minOcena = PromptInt("Minimalna ocena (npr. 8): ");
                        xmlQuery.IzpisiPredmeteZNadOceno(minOcena);
                        break;

                    case "3":
                        var letnik = PromptInt("Letnik (npr. 1, 2 ali 3): ");
                        xmlQuery.IzpisiStatistikoOcenLetnik(letnik);
                        break;

                    case "4":
                        xslt.TransformToHtml(xmlStudenti, xsltHtml, Path.Combine(outDir, "studenti.html"));
                        Console.WriteLine("HTML generiran: out/studenti.html");
                        break;

                    case "5":
                        // opcija: lahko najprej generiraš .fo v out/porocilo.fo
                        xslt.TransformToFo(xmlStudenti, xsltFo, Path.Combine(outDir, "porocilo.fo"));
                        pdf.GeneratePdfFromFo(Path.Combine(outDir, "porocilo.fo"), Path.Combine(outDir, "porocilo.pdf"));
                        Console.WriteLine("PDF generiran: out/porocilo.pdf");
                        break;

                    case "6":
                        docx.CreateDocxFromXml(xmlStudenti, Path.Combine(outDir, "porocilo.docx"));
                        Console.WriteLine("DOCX generiran: out/porocilo.docx");
                        break;

                    case "7":
                        docx.ExtractToUniversalXml(Path.Combine(outDir, "porocilo.docx"), Path.Combine(outDir, "UniversalData.xml"));
                        Console.WriteLine("UniversalData.xml generiran: out/UniversalData.xml");

                        var ok = validator.Validate(Path.Combine(outDir, "UniversalData.xml"), xsdUniversal);
                        Console.WriteLine(ok
                            ? "Validacija proti UniversalSchema.xsd: OK"
                            : "Validacija NI uspela (preveri napake).");
                        break;

                    case "8":
                        // uporabi XSLT za UniversalData -> HTML/PDF
                        xslt.TransformToHtml(Path.Combine(outDir, "UniversalData.xml"), Path.Combine(dataDir, "universal_html.xsl"), Path.Combine(outDir, "universal.html"));
                        xslt.TransformToFo(Path.Combine(outDir, "UniversalData.xml"), Path.Combine(dataDir, "universal_fo.xsl"), Path.Combine(outDir, "universal.fo"));
                        pdf.GeneratePdfFromFo(Path.Combine(outDir, "universal.fo"), Path.Combine(outDir, "universal.pdf"));
                        Console.WriteLine("Generirano: out/universal.html in out/universal.pdf");
                        break;

                    case "0":
                        return;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("[Napaka] " + ex.Message);
            }
        }
    }

    static int PromptInt(string label)
    {
        Console.Write(label);
        var input = Console.ReadLine();
        if (int.TryParse(input, NumberStyles.Any, CultureInfo.InvariantCulture, out var value))
            return value;

        Console.WriteLine("Neveljaven vnos, privzeto: 0");
        return 0;
    }
}
