﻿using Preverjanje2b.src.Models;

namespace Preverjanje2b.src.Models;

public class Student
{
    public string Id { get; set; } = "";
    public string Ime { get; set; } = "";
    public string Priimek { get; set; } = "";
    public string VpisnaStevilka { get; set; } = "";
    public List<Predmet> Predmeti { get; set; } = new();
}
