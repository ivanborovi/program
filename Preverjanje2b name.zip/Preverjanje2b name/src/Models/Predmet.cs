﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Preverjanje2b.src.Models
{
    public class Predmet
    {
        public string Koda { get; set; } = "";
        public string Naziv { get; set; } = "";
        public int KreditneTocke { get; set; }
        public int Ocena { get; set; }
    }
}
