﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Preverjanje1b.src.Models;

namespace Preverjanje1b.src.Services
{
    internal class TxtService
    {
        private readonly string _inputPath;
        private readonly string _outputPath;

        public TxtService(string inputPath, string outputPath)
        {
            _inputPath = inputPath;
            _outputPath = outputPath;
            //Directory.CreateDirectory(Path.GetDirectoryName(_inputPath)!);
            //Directory.CreateDirectory(Path.GetDirectoryName(_outputPath)!);
            if (!File.Exists(_inputPath)) File.WriteAllText(_inputPath, "");
        }

        // TODO(1): Dodaj študenta v TXT datoteko v obliki:
        // Ime;Priimek;Povprecje;Letnik
        public void DodajStudent(Student s)
        {
            var line = $"{s.Ime};{s.Priimek};{s.Povprecje.ToString(CultureInfo.InvariantCulture)};{s.Letnik}";
            File.AppendAllText(_inputPath, line + Environment.NewLine);
        }

        // TODO(2): Preberi vse študente iz TXT
        public IEnumerable<Student> PreberiVse()
        {
            var lines = File.ReadAllLines(_inputPath);
            var students = new List<Student>();

            foreach (var line in lines)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                var parts = line.Split(';');
                if (parts.Length >= 4)
                {
                    var student = new Student
                    {
                        Ime = parts[0],
                        Priimek = parts[1],
                        Povprecje = decimal.Parse(parts[2], CultureInfo.InvariantCulture),
                        Letnik = int.Parse(parts[3])
                    };
                    students.Add(student);
                }
            }

            return students;
        }

        // TODO(3): Vrni študente, katerih povprečje >= threshold
        public IEnumerable<Student> FilterByAverage(decimal threshold)
        {
            return PreberiVse().Where(s => s.Povprecje >= threshold);
        }

        // TODO(4): Povišaj povprečja za podani % in zapiši v _outputPath (isti format kot vhod)
        public void BoostAverages(decimal percent)
        {
            var students = PreberiVse().ToList();
            var lines = new List<string>();

            foreach (var student in students)
            {
                var boostedAverage = student.Povprecje * (1 + percent / 100);
                // Cap at 10.0
                if (boostedAverage > 10.0m)
                    boostedAverage = 10.0m;

                var line = $"{student.Ime};{student.Priimek};{boostedAverage.ToString(CultureInfo.InvariantCulture)};{student.Letnik}";
                lines.Add(line);
            }

            File.WriteAllLines(_outputPath, lines);
        }
    }
}