﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Preverjanje1b.src.Models;

namespace Preverjanje1b.src.Services
{
    internal class TxtService
    {
        private readonly string _inputPath;
        private readonly string _outputPath;

        public TxtService(string inputPath, string outputPath)
        {
            _inputPath = inputPath;
            _outputPath = outputPath;
            //Directory.CreateDirectory(Path.GetDirectoryName(_inputPath)!);
            //Directory.CreateDirectory(Path.GetDirectoryName(_outputPath)!);
            if (!File.Exists(_inputPath)) File.WriteAllText(_inputPath, "");
        }

        // TODO(1): Dodaj študenta v TXT datoteko v obliki:
        // Ime;Priimek;Povprecje;Letnik
        public void DodajStudent(Student s)
        {
            throw new NotImplementedException("TODO: DodajStudent");
        }

        // TODO(2): Preberi vse študente iz TXT
        public IEnumerable<Student> PreberiVse()
        {
            throw new NotImplementedException("TODO: PreberiVse");
        }

        // TODO(3): Vrni študente, katerih povprečje >= threshold
        public IEnumerable<Student> FilterByAverage(decimal threshold)
        {
            throw new NotImplementedException("TODO: FilterByAverage");
        }

        // TODO(4): Povišaj povprečja za podani % in zapiši v _outputPath (isti format kot vhod)
        public void BoostAverages(decimal percent)
        {
            throw new NotImplementedException("TODO: BoostAverages");
        }
    }
}
