﻿// See https://aka.ms/new-console-template for more information

using System.Globalization;
using Preverjanje1b.src.Models;
using Preverjanje1b.src.Services;

namespace Preverjanje1b.src;

class Program
{
    static void Main()
    {
        Console.WriteLine("Hello, World!");

        Console.OutputEncoding = System.Text.Encoding.UTF8;

// string baseDir = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, @"../../..")); // Mac
        string baseDir = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, @"..\..\..")); // Windows
        string dataDir = Path.Combine(baseDir, "data");
        string outDir = Path.Combine(baseDir, "out");

        Directory.CreateDirectory(dataDir);
        Directory.CreateDirectory(outDir);

        var txt = new TxtService(Path.Combine(dataDir, "studenti.txt"), Path.Combine(outDir, "posodobljeni.txt"));
        var xml = new XmlService(Path.Combine(dataDir, "studenti.xml"), Path.Combine(dataDir, "predmeti.xml"),
            Path.Combine(dataDir, "model.dtd"), Path.Combine(dataDir, "model.xsd"));

        while (true)
        {
            Console.WriteLine("\n=== MENI ===");
            Console.WriteLine("1) TXT: Dodaj študenta");
            Console.WriteLine("2) TXT: Izpiši vse");
            Console.WriteLine("3) TXT: Filtriraj po povprečju (>=)");
            Console.WriteLine("4) TXT: Povišaj povprečja (%) -> out/posodobljeni.txt");
            Console.WriteLine("5) XML: Dodaj študenta (z ID in predmeti)");
            Console.WriteLine("6) XML: Dodaj predmet");
            Console.WriteLine("7) XML: Izpiši študente z njihovimi predmeti");
            Console.WriteLine("8) XML: Validiraj oba dokumenta (XSD)");
            Console.WriteLine("0) Izhod");
            Console.Write("Izbira: ");
            var choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    var s = PromptStudentBasic();
                    txt.DodajStudent(s);
                    Console.WriteLine("Dodano v TXT.");
                    break;
                case "2":
                    foreach (var st in txt.PreberiVse())
                        Console.WriteLine(st);
                    break;
                case "3":
                    Console.Write("Meja (npr. 8.0): ");
                    if (decimal.TryParse(Console.ReadLine(), NumberStyles.Any, CultureInfo.InvariantCulture,
                            out var lim))
                        foreach (var st in txt.FilterByAverage(lim))
                            Console.WriteLine(st);
                    else Console.WriteLine("Neveljaven vnos.");
                    break;
                case "4":
                    Console.Write("Odstotek (npr. 5): ");
                    if (decimal.TryParse(Console.ReadLine(), NumberStyles.Any, CultureInfo.InvariantCulture,
                            out var pct))
                    {
                        txt.BoostAverages(pct);
                        Console.WriteLine("Zapisano v out/posodobljeni.txt");
                    }
                    else Console.WriteLine("Neveljaven vnos.");

                    break;
                case "5":
                    var sx = PromptStudentWithRefs();
                    xml.DodajStudent(sx);
                    break;
                case "6":
                    var subj = PromptSubject();
                    xml.DodajPredmet(subj);
                    break;
                case "7":
                    foreach (var line in xml.IzpisiStudenteSPredmeti())
                        Console.WriteLine(line);
                    break;
                case "8":
                {
                    bool ok1 = xml.ValidateFileWithXsd("studenti");
                    bool ok2 = xml.ValidateFileWithXsd("predmeti");
                    Console.WriteLine(
                        $"XSD validacija -> studenti: {(ok1 ? "OK" : "NAPAKA")}, predmeti: {(ok2 ? "OK" : "NAPAKA")}");
                    break;
                }
                case "0":
                    return;
            }
            /* }
             catch (Exception ex)
             {
                 Console.WriteLine("[Napaka] " + ex.Message);
             }*/
        }
    }

    static Student PromptStudentBasic()
    {
        Console.Write("Ime: ");
        var ime = Console.ReadLine() ?? "";
        Console.Write("Priimek: ");
        var priimek = Console.ReadLine() ?? "";
        Console.Write("Povprečje (npr. 8.5): ");
        decimal.TryParse(Console.ReadLine(), NumberStyles.Any, CultureInfo.InvariantCulture, out var povp);
        Console.Write("Letnik (1-3): ");
        int.TryParse(Console.ReadLine(), out var letnik);
        return new Student { Ime = ime, Priimek = priimek, Povprecje = povp, Letnik = letnik };
    }

    static Student PromptStudentWithRefs()
    {
        var s = PromptStudentBasic();
        Console.Write("ID študenta (npr. S3): ");
        s.Id = Console.ReadLine() ?? "S?";
        Console.Write("Predmeti (ID-ji, npr. P1,P2): ");
        s.PredmetRefs = (Console.ReadLine() ?? "")
            .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
        return s;
    }

    static Predmet PromptSubject()
    {
        Console.Write("ID predmeta (npr. P3): ");
        var id = Console.ReadLine() ?? "P?";
        Console.Write("Naziv: ");
        var naziv = Console.ReadLine() ?? "";
        Console.Write("ECTS (1-10): ");
        int.TryParse(Console.ReadLine(), out var ects);
        Console.Write("Obvezen (da/ne): ");
        var obv = Console.ReadLine() ?? "da";
        Console.Write("Predavatelj: ");
        var pred = Console.ReadLine() ?? "";
        return new Predmet { Id = id, Naziv = naziv, ECTS = ects, Obvezen = obv, Predavatelj = pred };
    }
}